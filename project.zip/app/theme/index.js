import colors from './colors';
import fontSize from './fontSize';
import fontWeight from './fontWeight';
import responsiveSize from './responsiveSize';

export {colors, fontSize, fontWeight, responsiveSize};
