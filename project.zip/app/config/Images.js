/* @flow */

export default {
  cross: require('app/config/assets/Images/cross.png'),
  backIcon: require('app/config/assets/Images/back.png'),
};
