const SERVER = 'http://demo/api/1.0.0/';

module.exports = {
  SERVER,
};
