import IBText from './IBText';

export {IBText};
